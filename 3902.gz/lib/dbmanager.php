<?php

/**
 * File: dbmanager.php
 * Description: Handles database queries 
 */

/**
 * Return the n most recent reviews
 * @param count Number of reviews to return
 * @return MySQL query object
 */
function get_recent_reviews($count){
	$query = query(sprintf('SELECT g.game_title, r.review_id, r.date_submitted, r.uid, review_counter.review_total 
	FROM review r, game g, (SELECT count(*) AS review_total FROM review) AS review_counter
	WHERE r.game_id = g.game_id
	AND 1
	ORDER BY date_submitted DESC
	LIMIT %d', $count));
	
	return $query;
}

/**
 * Return the most recent n games added 
 * @param $count number of records to return
 * @return MySQL query object
 */
function get_recent_games($count){
	$query = query(sprintf('SELECT * FROM game ORDER BY added DESC LIMIT %d', $count));
	return $query;
}

/**
 * Return all games
 * @return MySQL query 
 */
function get_all_games($count = 10){
	$query = query(sprintf('SELECT * FROM game ORDER BY added DESC LIMIT %d', $count));
	
	return $query;
}

/**
 * Return information for a given game_id
 * @param $game_id The game id to return information for
 * @return MySQL query object
 */
function get_game($game_id){
	$query = query(sprintf('SELECT * FROM game WHERE game_id = %d', $game_id));
	
	$game = mysql_fetch_array($query);
	
	return $game; 
}

/**
 * Get reviews for a given game id
 * @param $game_id Game to id to get review for
 * @return MySQL query object
 */
function get_game_reviews($game_id){
	$query = query(sprintf('SELECT * FROM review r WHERE game_id = %d ORDER BY date_submitted DESC', $game_id));
	
	return $query;
}

/**
 * Return the count of reviews
 * @return MySQL query object
 */
function get_review_count(){
	$query = query(sprintf('SELECT count(*) AS total_count FROM review'));
	
	if($row = mysql_fetch_assoc($query)){
		return $row['total_count'];
	}else {
		return 0;
	}
}

/**
 * Return the number of games in the database
 * @return MySQL query object
 */
function get_game_count(){
	$query = query(sprintf('SELECT count(*) AS total_count FROM game'));
	
	if($row = mysql_fetch_assoc($query)){
		return $row['total_count'];
	} else {
		return 0;
	}
}

/**
 * Calculate the average rating for this particular game
 * @param game_id game rating to calculate 
 * @return MySQL query object
 */
function get_game_rating($game_id){
	$query = query(sprintf('SELECT avg(rating) AS game_rating FROM review WHERE game_id = %d', $game_id));
	
	if($row = mysql_fetch_assoc($query)){
		return round($row['game_rating']);
	} else {
		return 0;
	}
}

/**
 * Count how many reviews a game has
 * @param game_id game rating to calculate 
 * @return MySQL query object
 */
function get_game_review_count($game_id){
	$query = query(sprintf('SELECT count(*) AS review_count FROM review WHERE game_id = %d', $game_id));
	
	if($row = mysql_fetch_assoc($query)){
		return $row['review_count'];
	} else {
		return 0;
	}
}

/**
 * Add a game to the database
 * 
 * @param $title
 * @param $publisher
 * @param $year
 * @param $esrb
 * @return
 */
function add_game($title, $publisher, $year, $esrb, $asin){
	return query(sprintf("INSERT INTO game(game_title, publisher, release_year, esrb_rating, asin)
		VALUES ('%s', '%s', %d, '%s', '%s')", $title, $publisher, $year, $esrb, $asin));
}

/**
 * Test if a games exists in the database
 *
 * @param String $title
 * @return boolean
 */
function game_exists($title){
	 $query = query(sprintf("SELECT count(*) as game_count FROM game WHERE game_title LIKE '%s'", $title));
	
	 $test = 0;
	 
	if($row = mysql_fetch_assoc($query)){
		if($row['game_count'] == 1){
			$test = 1;
		} 
	} 
	
	return $test;
}

/**
 * Add a review to the database
 *
 * @param Int $uid
 * @param Int $rating
 * @param String $review
 * @param Int $game_id
 * @return unknown
 */
function add_review($uid, $rating, $review, $game_id){
	return query(sprintf("INSERT INTO review(uid, rating, review, game_id)
		VALUES (%d, %d, '%s', %d)", $uid, $rating, $review, $game_id));
}

/**
 * Get a review
 *
 * @param int $review_id
 */
function get_review($review_id){
	$query = query(sprintf("SELECT * FROM review WHERE review_id = %d", $review_id));
	return $query;
}

/**
 * Get all reviews
 *
 * @param int $count 
 */
function get_all_reviews($count = 10){
	$query = query(sprintf("SELECT * FROM review ORDER BY date_submitted DESC LIMIT %d", $count));
	
	return $query;
}

/**
 * Get a specific game title
 *
 * @param int $game_id
 */
function get_game_title($game_id){
	$query = query(sprintf("SELECT game_title FROM game WHERE game_id = '%s'", $game_id));
	
	if($row = mysql_fetch_assoc($query)){
		if($row['game_title']){
			return $row['game_title'];
		} else {
			return 'Title not found';
		}
	}
}

/**
 * Test if an asin exists in the database
 *
 * @param String $asin
 * @return boolean
 */
function game_exists_asin($asin){
	 $query = query(sprintf("SELECT count(*) as game_count FROM game WHERE asin = '%s'", $asin));
	
	 $test = 0;
	 
	if($row = mysql_fetch_assoc($query)){
		if($row['game_count'] == 1){
			$test = 1;
		} 
	} 
	
	return $test;
}

/**
 * Encapsulate the query connection to MySQL
 *
 * @param String $sql
 * @return mysql_query
 */ 
function query($sql){
	global $conn;
	return mysql_query($sql, $conn);
}

?>
