<?php
/**
 * File: index.php
 * Description: The index file of the application
 */

require_once('config/config.inc.php');
require_once('lib/dbmanager.php');

$recent_reviews = get_recent_reviews(5);
$review_count = get_review_count();

$recent_games = get_recent_games(5);
$game_count = get_game_count();
 
?>

<style>
<?php require_once('style/style.css'); ?>
</style>

<div id="body">
	<div id="left-wide">	
		<div id="reviews">
			<!-- recent reviews -->
			<h2 class="header">Recent Reviews</h2>
			
			<div class="subheader clearfix">
				<div class="left">
				<?php
					echo('Displaying Latest 5 of ' . $review_count .' Reviews');
				?>
				</div>
				<div class="right">
					<a href="reviews.php">See all reviews</a>
				</div>
				
			</div>
			
			<div class="reviews box clearfix ">
				
			<?php
				
				while ($row = mysql_fetch_array($recent_reviews)) {
					echo('<div class="review clearfix"><h3 class="review_title"><a href="reviews.php?action=display&review_id=' . $row['review_id']. '">'. $row['game_title'] . '</a></h3');
					echo('<p class="more_info clearfix">Submitted ' . $row['date_submitted'] . '</p></div>');
				}
			?>
				
			</div>
		</div>
	</div>
	
	<div id="right-small">
		<div class="box">
			<h2 class="header">recently added games</h2>
			<div class="subheader clearfix">
				
				<div class="right">
					<a href="games.php">See all games</a>
				</div>
			</div>
			<div class="clearfix">
				<?php
					while($row = mysql_fetch_array($recent_games)){
						echo('<h3 class="game_info"><a href="games.php?action=display&game_id=' . $row['game_id'] .'">' . $row['game_title'] . '</a></h3>');
					}			
				?>
			</div>
		</div>
	</div>
</div>