<?php
class AmazonClient {

	public $amazon_key; 
	public $amazon_id;  
	
	public function __construct($amazon_key, $amazon_id = ''){
		$this->amazon_key = $amazon_key;
		$this->amazon_id = $amazon_id;
	}
	
	/**
	 * Return an array of n possible asins
	 */
	function asin_lookup($title){
		$params = array('Title' => $title, 'Operation' => 'ItemSearch', 
					'ResponseGroup' => 'ItemAttributes');
		
		$xml = $this->amazon_search($params);
		
		$xml_result = $xml->Items->Item;
		
		return $xml_result->ASIN;
	}

	/**
	 * Return an array of the images (small, medium, 
	 * 	and large) for a given ASIN
	 * @param $asin The ASIN number to search
	 */
	function get_game_image($asin){
		$params = array( 'Keywords' => $asin, 
				 'Operation' => "ItemSearch", 
				 'ResponseGroup' => 'Images' );
		
		$xml = $this->amazon_search($params);
				
		$results = array();
		
		foreach($xml->Items->Item as $item){
			
			$results['small_url'] = $item->SmallImage->URL;
			$results['small_height'] = $item->SmallImage->Height;
			$results['small_width'] = $item->SmallImage->Width;
			
			$results['medium_url'] = $item->MediumImage->URL;
			$results['medium_height'] = $item->MediumImage->Height;
			$results['medium_width'] = $item->MediumImage->Width;
			
			$results['large_url'] = $item->LargeImage->URL;
			$results['large_height'] = $item->LargeImage->Height;
			$results['large_width'] = $item->LargeImage->Width;
		}
		
		return $results;
	}
	
	/**
 	 * Function to build query string for AWS
 	 * @param $params search parameters to pass to AWS
 	 * @return AWS REST query URL string
 	 */
	function build_query($params){
		$constants = array('Service' => 'AWSECommerceService',
				   'SubscriptionId' => $this->amazon_key,
				   'AssociateTag' => $this->amazon_id,
				   'SearchIndex' => 'VideoGames');
		
		$query_string = '';
		
		// add params to search string
		foreach($constants as $key => $value){
			$query_string .= "$key=" . urlencode($value) . "&";
		}
		
		// add searchparams to search string
		foreach($params as $key => $value){
			$query_string .= "$key=" . urlencode($value) . "&";
		}
		
		return 'http://ecs.amazonaws.com/onca/xml?' . $query_string;
	}
	
	/**
     * Simple REST client for Amazon AWS
     * @param $params Query parameters to pass to AWS
     * @return SimpleXML object of the REST response
     */
	function amazon_search($params){
		$url = $this->build_query($params);
		
		$response = file_get_contents($url);	
		
		$xmlObject = simplexml_load_string($response);
		
		return $xmlObject;
	}
	
}
?>
