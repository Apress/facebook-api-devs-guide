<?php
/**
 * File: games.php
 * Description: Views of the games in the database
 */
require_once('config/config.inc.php');	
require_once('lib/dbmanager.php');
require_once('lib/amazon.php');
	
if(isset($_REQUEST['action'])){
	$action = $_REQUEST['action'];
}else {
	$action = '';
}
?>

<style>
<?php require_once('style/style.css'); ?>
</style>

<div id="body">

<a href="games.php">all games</a> <a href="#" clicktoshowdialog="add_game">add game</a>

<?php
	if(isset($_GET['message'])){
		if($_GET['type'] == "success"){
			echo('<fb:success message="' . $_GET['message'] . '"/>');
		}
		else {
			echo('<fb:error message="' . $_GET['message'] . '"/>');
		}
	}
?>

<fb:dialog id="add_game" cancel_button="1">
	<fb:dialog-title>Add New Game</fb:dialog-title>
	<fb:dialog-content>
		<form id="add_game_form" method="post" action="add_game.php">
			<table>
				<tr>
					<td>Game Title:</td>
					<td><input type="text" name="game_title" /></td>
				</tr>
				<tr>
					<td>Publisher:</td>
					<td><input type="text" name="publisher" /></td>
				</tr>
				<tr>
					<td>Year Released:</td>
					<td><input type="text" name="release_year" /></td>
				</tr>
				<tr>
					<td>Rating:</td>
					<td><select name="esrb_rating">
						<option value="EC">EC</option>
						<option value="E" selected>E</option>
						<option value="E10+">E10+</option>
						<option value="T">T</option>
						<option value="M">M</option>
						<option value="AO">AO</option>
					</select></td>
				</tr>
			</table>
		</form>
	</fb:dialog-content>
	
	<fb:dialog-button type="submit" value="Add Game" form_id="add_game_form" /> 
	
</fb:dialog>

<?php
 
	if($action == 'display'){
		
		// temporary rule for hacked url
		if(! isset($_REQUEST['game_id'])){
			$_REQUEST['game_id'] = 1;
		}
		
		$game_id = $_REQUEST['game_id'];
		$game = get_game($game_id);
		
		$game_rating = get_game_rating($game_id);
		$game_reviews = get_game_reviews($game_id);
		
		$title = $game['game_title'];
		$game_id = $game['game_id'];
		$publisher = $game['publisher'];
		$year = $game['release_year'];
		$rating = $game['esrb_rating'];
		$added = date('d M, Y', strtotime($game['added']));
			
		$game_rating = get_game_rating($game_id);
		$review_count = get_game_review_count($game_id);
				
		$amazon = new AmazonClient($amazon_key);
		$images = $amazon->get_game_image($game['asin']);
		
		if(sizeof($images) > 0){
			$image = $images['medium_url'];
			$img = '<img src=' . $image. " />";
		} else {
			$img = 'No Image Available';
		}
		
		echo <<<EOT
<div class="game">
	<div class="game_image">
		$img		
	</div>
	<div class="game_about_medium">
		<p class="game_header">
			<a href="games.php?game_id=$game_id&action=display">
				$title
			</a>
			by $publisher ($year)
		</p>
		<p><strong>Rating:</strong> <img src="$callback_url/images/$game_rating.png" alt="$game_rating" title="Average rating of $game_rating" /> ($review_count total reviews)</p>
		<p><strong>ESRB Rating:</strong> $rating</p>
		<p><strong>Added:</strong> $added</p>
	</div>
	<div class="bumper" />
</div>		
EOT;

		print('<div id="reviews">');
		
		while($row = mysql_fetch_assoc($game_reviews)){
			$uid = $row['uid'];
			$rating = $row['rating'];
			$review = nl2br($row['review']);
			$submitted = strtotime($row['date_submitted']);
			
			$time = date('h:ia', $submitted);
			$date = date('d M, Y', $submitted);
			$stars = $callback_url . '/images/' . $rating . '.png';
		
			
			echo <<< EOT
<div class="review">
	<div class="userimage">
		<fb:profile-pic uid="$uid" linked="true" size="q" />
	</div>
	
	<div class="review_box">
		<div class="review_header">
			<fb:name uid="$uid" capitalize="true" linked="true" /> reviewed <strong>$title</strong> <br/>
			at $time on $date
		</div>
		<div class="review_text">
			<p>$review</p>
			<p><img src="$stars" /></p>
		</div>
	</div>
</div>
EOT;
		
		}
		
		print('<a href="reviews.php?game_id=' . $game['game_id'] . '&action=add">add a review</a>');
		
		print('</div>');	
	
	}else if($action == 'add'){
		
		print('<div class="mock_form" style="display:none;"></div>');
	
		print('<form method="post" action="add_game">');
		print('Game Title: <input type="input" name="game_title" />');
		print('Publisher: <input type="input" name="publisher" />');
		print('Year Released: <input type="input" name="release_year" />');
		print('</form>');
		
		
		
	} else if($action == 'display'){
		
	}else {
		$all_games = get_all_games();
		
		print('<div id="games">');
		
		$amazon = new AmazonClient($amazon_key);
		
		while ($row = mysql_fetch_array($all_games)){
						
			$title = $row['game_title'];
			$game_id = $row['game_id'];
			$publisher = $row['publisher'];
			$year = $row['release_year'];
			$rating = $row['esrb_rating'];
			$added = date('d M, Y', strtotime($row['added']));
			
			$game_rating = get_game_rating($game_id);
			$review_count = get_game_review_count($game_id);
			
			
			$images = $amazon->get_game_image($row['asin']);
			
			if(sizeof($images) > 0){
				$image = $images['small_url'];
				$img = '<img src="' . $image . '" />';
			} else {
				$img = 'No Image Available';
			}			
			
			echo <<<EOT
<div class="game">
	<div class="game_image">
		$img		
	</div>
	<div class="game_about">
		<p class="game_header">
			<a href="games.php?game_id=$game_id&action=display">
				$title
			</a>
			by $publisher ($year)
		</p>
		<p><strong>Rating:</strong> <img src="$callback_url/images/$game_rating.png" alt="$game_rating" title="Average rating of $game_rating" /> ($review_count total reviews)</p>
		<p><strong>ESRB Rating:</strong> $rating</p>
		<p><strong>Added:</strong> $added</p>
		<p><a href="games.php?action=display&game_id=$game_id">see reviews</a></p>
	</div>
	<div class="bumper" />
</div>			
EOT;
		}
		
		print('</div>');
	}
	
?>


</div>
