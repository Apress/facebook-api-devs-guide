<?php
/**
 * File: reviews.php
 * Description: Views of the reviews in the database
 */

require_once('config/config.inc.php');
require_once('lib/dbmanager.php');

if( isset($_REQUEST['action'])){
	$action = $_REQUEST['action'];
} else {
	$action = '';
}

?>

<style>
<?php require_once('style/style.css'); ?>
</style>

<div id="body">

<a href="reviews.php">all reviews</a> <a href="#" clicktoshowdialog="add_review">add review</a>

<?php
	if(isset($_GET['message'])){
		if($_GET['type'] == "success"){
			echo('<fb:success message="' . $_GET['message'] . '"/>');
		}
		else {
			echo('<fb:error message="' . $_GET['message'] . '"/>');
		}
	}
?>

<fb:dialog id="add_review" cancel_button="1">
	<fb:dialog-title>Add New Game Review</fb:dialog-title>
	<fb:dialog-content>
		<form id="add_review_form" method="post" action="add_review.php">
			<table>
				<tr>
					<td>Game Title:</td>
					<!-- do a type-ahead to locate games... -->
					<td>
					<fb:fbml version="1.1">
						<fb:typeahead-input name="game_id">
							<?php
								$all_games = get_all_games();
								while($row = mysql_fetch_array($all_games)){
									echo('<fb:typeahead-option value="' . $row['game_id'] . '">');
									echo($row['game_title']);
									echo('</fb:typeahead-option>');										
								}
							?>
						</fb:typeahead-input>
					</fb:fbml>
					</td>
					
				</tr>
				<tr>
					<td>Rating:</td>
					<td>
						<input type="radio" value="1" name="rating"> 1
						<input type="radio" value="2" name="rating"> 2
						<input type="radio" value="3" name="rating" checked> 3
						<input type="radio" value="4" name="rating"> 4
						<input type="radio" value="5" name="rating"> 5
					</td>
				</tr>
				<tr>
					<td>Review:</td>
					<td>&nbsp;</td>
				</tr>
				<tr>
					<td>&nbsp;</td>
					<td><textarea name="review"></textarea></td>
				</tr>
			</table>
		</form>
	</fb:dialog-content>
	
	<fb:dialog-button type="submit" value="Add Review" form_id="add_review_form" /> 
	
</fb:dialog>

<?php
	if($action == 'display'){
		echo('display');
	}else if ($action == 'something'){
		
	} else { // display all reviews
		$all_reviews = get_all_reviews();
		
		print('<div id="reviews">');
		
		while($row = mysql_fetch_assoc($all_reviews))
		{
			$uid = $row['uid'];
			$rating = $row['rating'];
			$review = nl2br($row['review']);
			$submitted = strtotime($row['date_submitted']);
			
			$time = date('h:ia', $submitted);
			$date = date('d M, Y', $submitted);
			$stars = $callback_url . '/images/' . $rating . '.png';
			
			$title = get_game_title($row['game_id']);
			
			$game_link = 'games.php?action=display&game_id=' . $row['game_id'];
			
			echo <<< EOT
<div class="review">
	<div class="userimage">
		<fb:profile-pic uid="$uid" linked="true" size="q" />
	</div>
	
	<div class="review_box">
		<div class="review_header">
			<fb:name uid="$uid" capitalize="true" linked="true" /> reviewed <strong><a href="$game_link">$title</a></strong> <br/>
			at $time on $date
		</div>
		<div class="review_text">
			<p>$review</p>
			<p><img src="$stars" /></p>
		</div>
	</div>
</div>
EOT;
		}
		
		print('</div>');
		
	}
	
?>

</div>
