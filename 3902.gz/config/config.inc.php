<?php

/**
 * Facebook settings
 */
$facebook_config['debug'] = true;
$facebook_config['api_key'] = '';
$facebook_config['secret'] = '';

/**
 * include the facebook client library
 */
require_once('lib/facebook.php');

/**
 * Set up the facebook object
 */
$facebook = new Facebook($facebook_config['apk_key'], $facebook_config['secret']);

$user = $facebook->require_login();

$callback_url = '';

/**
 * MySQL settings
 */
$database_server = '';
$database_user = '';
$database_password = '';
$database_name = '';

$conn = mysql_connect($database_server, $database_user, $database_password);
@mysql_select_db($database_name);

/**
 * Amazon settings
 */
$amazon_key = '';
$amazon_tag = '';

?> 
