<?php
/**
 * File: add_game.php
 * Description: Add a game to the application
 */

require_once('config/config.inc.php');
require_once('lib/dbmanager.php');
require_once('lib/amazon.php');


if(isset($_REQUEST['game_title'])){
	$game_title = $_REQUEST['game_title'];
	
	$type = "error";
	
	if(game_exists($game_title)){
		// check to see if the title exists
		$message = "Sorry, looks like " . $game_title;
		$message += " is already in our database";
	} else {
		// check in Amazon
		$amazon = new AmazonClient($amazon_key);
		
		$asin = $amazon->asin_lookup($game_title);
		
		if(strlen($asin) > 0){
			// double check this in the database
			
			if(game_exists_asin($asin)){
				$message = "Sorry, looks like " . $game_title;
				$message += " is already in our database"; 
			} else {
				add_game($_REQUEST['game_title'], $_REQUEST['publisher'], 
					$_REQUEST['release_year'], $_REQUEST['esrb_rating'], $asin);
				$message = $_REQUEST['game_title'] . " was successfully added to";
				$message += " the database.  Please be sure to write a review!";
				$type = "success";
				
				$title_template = "";
				
				$facebook->api_client->feed_publishTemplatizedAction($user, "{actor} is adding games to Apress Sample App", '', '', '', '');
			}
		} else {
			$message = "Sorry, couldn't find " . $_REQUEST['game_title']; 
			$message += " at Amazon.";
		}
	}
	
	
	
	echo('<fb:redirect url="games.php?message=' . urlencode($message) . '&type=' . $type . '" />');
}


?>
