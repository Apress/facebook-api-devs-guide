<?php
/**
 * File: add_review.php
 * Description: Add a review to the application
 */	

require_once('config/config.inc.php');
require_once('lib/dbmanager.php');
	
$uid = $_REQUEST['fb_sig_user'];
$rating = $_REQUEST['rating'];
$review = $_REQUEST['review'];
$game_id = $_REQUEST['game_id_val'];

$type = "error";


	
add_review($uid, $rating, $review, $game_id);
	
$message = "Added review of " . $_REQUEST['game_id'];

	
echo('<fb:redirect url="reviews.php?message=' . urlencode($message) . '&type=' . $type . '" />');
	
?> 
